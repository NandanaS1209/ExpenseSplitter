import React, { useState } from 'react';

function App() {
    const [users, setUsers] = useState([]);
    const [userName, setUserName] = useState('');
    const [expenses, setExpenses] = useState([]);
    const [expenseDesc, setExpenseDesc] = useState('');
    const [expenseAmount, setExpenseAmount] = useState('');
    const [expensePaidBy, setExpensePaidBy] = useState('');
    const [expenseParticipants, setExpenseParticipants] = useState([]);
    const [settlements, setSettlements] = useState([]);

    // Add user
    const addUser = () => {
        if (userName.trim() && !users.includes(userName.trim())) {
            setUsers([...users, userName.trim()]);
            setUserName('');
        }
    };

    // Handle participant checkbox change
    const handleParticipantChange = (user, isChecked) => {
        if (isChecked) {
            setExpenseParticipants([...expenseParticipants, user]);
        } else {
            setExpenseParticipants(expenseParticipants.filter(p => p !== user));
        }
    };

    // Add expense
    const addExpense = () => {
        if (
            expenseDesc.trim() &&
            expenseAmount > 0 &&
            expensePaidBy &&
            expenseParticipants.length > 0
        ) {
            const newExpense = {
                id: Date.now(),
                description: expenseDesc.trim(),
                amount: parseFloat(expenseAmount),
                paidBy: expensePaidBy,
                participants: [...expenseParticipants],
                date: new Date().toLocaleDateString()
            };

            setExpenses([...expenses, newExpense]);
            setExpenseDesc('');
            setExpenseAmount('');
            setExpensePaidBy('');
            setExpenseParticipants([]);
        } else {
            alert('Please fill all fields and select at least one participant!');
        }
    };

    // Calculate settlements
    const calculateSettlements = () => {
        // Initialize balances for all users
        let balances = {};
        users.forEach(user => {
            balances[user] = 0;
        });

        // Calculate net balances
        expenses.forEach(expense => {
            const sharePerPerson = expense.amount / expense.participants.length;

            // Each participant owes their share
            expense.participants.forEach(participant => {
                balances[participant] -= sharePerPerson;
            });

            // The payer gets credited the full amount
            balances[expense.paidBy] += expense.amount;
        });

        // Generate settlements using greedy algorithm
        let settlementsList = [];
        let debtors = Object.entries(balances)
            .filter(([user, balance]) => balance < -0.01)
            .sort((a, b) => a[1] - b[1]); // Sort by debt amount (most negative first)

        let creditors = Object.entries(balances)
            .filter(([user, balance]) => balance > 0.01)
            .sort((a, b) => b[1] - a[1]); // Sort by credit amount (highest first)

        while (debtors.length && creditors.length) {
            let [debtor, debtAmount] = debtors[0];
            let [creditor, creditAmount] = creditors[0];

            let settleAmount = Math.min(-debtAmount, creditAmount);

            settlementsList.push({
                from: debtor,
                to: creditor,
                amount: settleAmount
            });

            // Update amounts
            debtAmount += settleAmount;
            creditAmount -= settleAmount;

            // Remove or update entries
            if (Math.abs(debtAmount) < 0.01) {
                debtors.shift();
            } else {
                debtors[0][1] = debtAmount;
            }

            if (creditAmount < 0.01) {
                creditors.shift();
            } else {
                creditors[0][1] = creditAmount;
            }
        }

        setSettlements(settlementsList);
    };

    // Clear all data
    const clearAllData = () => {
        if (window.confirm('Are you sure you want to clear all data?')) {
            setUsers([]);
            setExpenses([]);
            setSettlements([]);
            setUserName('');
            setExpenseDesc('');
            setExpenseAmount('');
            setExpensePaidBy('');
            setExpenseParticipants([]);
        }
    };

    // Delete expense
    const deleteExpense = (expenseId) => {
        setExpenses(expenses.filter(expense => expense.id !== expenseId));
        setSettlements([]); // Clear settlements when expenses change
    };

    return (
        <div style={{
            maxWidth: '800px',
            margin: '20px auto',
            fontFamily: 'Arial, sans-serif',
            padding: '20px',
            backgroundColor: '#f5f5f5',
            borderRadius: '10px'
        }}>
            <h1 style={{ textAlign: 'center', color: '#333', marginBottom: '30px' }}>
                💰 Expense Splitter
            </h1>

            {/* Add Users Section */}
            <div style={{
                backgroundColor: 'white',
                padding: '20px',
                borderRadius: '8px',
                marginBottom: '20px',
                boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
            }}>
                <h3 style={{ marginTop: 0, color: '#555' }}>👥 Add Users</h3>
                <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                    <input
                        type="text"
                        value={userName}
                        onChange={(e) => setUserName(e.target.value)}
                        placeholder="Enter user name"
                        style={{
                            flex: 1,
                            padding: '10px',
                            border: '1px solid #ddd',
                            borderRadius: '4px',
                            fontSize: '16px'
                        }}
                        onKeyPress={(e) => e.key === 'Enter' && addUser()}
                    />
                    <button
                        onClick={addUser}
                        style={{
                            padding: '10px 20px',
                            backgroundColor: '#007bff',
                            color: 'white',
                            border: 'none',
                            borderRadius: '4px',
                            cursor: 'pointer',
                            fontSize: '16px'
                        }}
                    >
                        Add User
                    </button>
                </div>
                <div style={{ marginTop: '15px' }}>
                    <strong>Users: </strong>
                    {users.length === 0 ? (
                        <span style={{ color: '#999' }}>No users added yet</span>
                    ) : (
                        <span style={{ color: '#007bff' }}>{users.join(', ')}</span>
                    )}
                </div>
            </div>

            {/* Add Expense Section */}
            <div style={{
                backgroundColor: 'white',
                padding: '20px',
                borderRadius: '8px',
                marginBottom: '20px',
                boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
            }}>
                <h3 style={{ marginTop: 0, color: '#555' }}>💸 Add Expense</h3>

                <div style={{ marginBottom: '15px' }}>
                    <input
                        type="text"
                        value={expenseDesc}
                        onChange={(e) => setExpenseDesc(e.target.value)}
                        placeholder="Expense description (e.g., Dinner, Taxi)"
                        style={{
                            width: '100%',
                            padding: '10px',
                            border: '1px solid #ddd',
                            borderRadius: '4px',
                            fontSize: '16px',
                            marginBottom: '10px'
                        }}
                    />

                    <div style={{ display: 'flex', gap: '10px', marginBottom: '10px' }}>
                        <input
                            type="number"
                            value={expenseAmount}
                            onChange={(e) => setExpenseAmount(e.target.value)}
                            placeholder="Amount (₹)"
                            style={{
                                flex: 1,
                                padding: '10px',
                                border: '1px solid #ddd',
                                borderRadius: '4px',
                                fontSize: '16px'
                            }}
                        />

                        <select
                            value={expensePaidBy}
                            onChange={(e) => setExpensePaidBy(e.target.value)}
                            style={{
                                flex: 1,
                                padding: '10px',
                                border: '1px solid #ddd',
                                borderRadius: '4px',
                                fontSize: '16px'
                            }}
                        >
                            <option value="">Who paid?</option>
                            {users.map(user => (
                                <option key={user} value={user}>{user}</option>
                            ))}
                        </select>
                    </div>
                </div>

                {/* Participants Selection */}
                {users.length > 0 && (
                    <div style={{ marginBottom: '15px' }}>
                        <label style={{ fontWeight: 'bold', display: 'block', marginBottom: '10px' }}>
                            Select participants:
                        </label>
                        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '15px' }}>
                            {users.map(user => (
                                <label key={user} style={{ display: 'flex', alignItems: 'center', cursor: 'pointer' }}>
                                    <input
                                        type="checkbox"
                                        checked={expenseParticipants.includes(user)}
                                        onChange={(e) => handleParticipantChange(user, e.target.checked)}
                                        style={{ marginRight: '8px', transform: 'scale(1.2)' }}
                                    />
                                    <span>{user}</span>
                                </label>
                            ))}
                        </div>
                    </div>
                )}

                <button
                    onClick={addExpense}
                    disabled={users.length === 0}
                    style={{
                        padding: '12px 24px',
                        backgroundColor: users.length === 0 ? '#ccc' : '#28a745',
                        color: 'white',
                        border: 'none',
                        borderRadius: '4px',
                        cursor: users.length === 0 ? 'not-allowed' : 'pointer',
                        fontSize: '16px',
                        fontWeight: 'bold'
                    }}
                >
                    Add Expense
                </button>
            </div>

            {/* Expenses List */}
            {expenses.length > 0 && (
                <div style={{
                    backgroundColor: 'white',
                    padding: '20px',
                    borderRadius: '8px',
                    marginBottom: '20px',
                    boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
                }}>
                    <h3 style={{ marginTop: 0, color: '#555' }}>📝 Expenses</h3>
                    {expenses.map(expense => (
                        <div key={expense.id} style={{
                            border: '1px solid #eee',
                            padding: '15px',
                            borderRadius: '6px',
                            marginBottom: '10px',
                            backgroundColor: '#f9f9f9'
                        }}>
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                <div>
                                    <strong>{expense.description}</strong> - ₹{expense.amount}
                                    <br />
                                    <small style={{ color: '#666' }}>
                                        Paid by {expense.paidBy} | Split among: {expense.participants.join(', ')} | {expense.date}
                                    </small>
                                    <br />
                                    <small style={{ color: '#007bff' }}>
                                        ₹{(expense.amount / expense.participants.length).toFixed(2)} per person
                                    </small>
                                </div>
                                <button
                                    onClick={() => deleteExpense(expense.id)}
                                    style={{
                                        padding: '5px 10px',
                                        backgroundColor: '#dc3545',
                                        color: 'white',
                                        border: 'none',
                                        borderRadius: '4px',
                                        cursor: 'pointer'
                                    }}
                                >
                                    Delete
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            )}

            {/* Settlement Calculation */}
            {expenses.length > 0 && (
                <div style={{
                    backgroundColor: 'white',
                    padding: '20px',
                    borderRadius: '8px',
                    marginBottom: '20px',
                    boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
                }}>
                    <h3 style={{ marginTop: 0, color: '#555' }}>⚖️ Settlement Calculator</h3>

                    <button
                        onClick={calculateSettlements}
                        style={{
                            padding: '12px 24px',
                            backgroundColor: '#ffc107',
                            color: '#000',
                            border: 'none',
                            borderRadius: '4px',
                            cursor: 'pointer',
                            fontSize: '16px',
                            fontWeight: 'bold',
                            marginBottom: '20px'
                        }}
                    >
                        🧮 Calculate Settlements
                    </button>

                    {settlements.length > 0 && (
                        <div>
                            <h4 style={{ color: '#555', marginBottom: '15px' }}>💳 Settlement Summary:</h4>
                            {settlements.map((settlement, index) => (
                                <div key={index} style={{
                                    padding: '12px',
                                    backgroundColor: '#e8f5e8',
                                    border: '1px solid #d4edda',
                                    borderRadius: '6px',
                                    marginBottom: '8px',
                                    fontSize: '16px'
                                }}>
                                    <strong>{settlement.from}</strong> owes <strong>{settlement.to}</strong>:
                                    <span style={{ color: '#dc3545', fontWeight: 'bold', marginLeft: '8px' }}>
                    ₹{settlement.amount.toFixed(2)}
                  </span>
                                </div>
                            ))}
                            <div style={{
                                marginTop: '15px',
                                padding: '10px',
                                backgroundColor: '#d4edda',
                                borderRadius: '4px',
                                textAlign: 'center',
                                color: '#155724',
                                fontWeight: 'bold'
                            }}>
                                ✅ Total settlements needed: {settlements.length}
                            </div>
                        </div>
                    )}

                    {settlements.length === 0 && expenses.length > 0 && (
                        <div style={{
                            padding: '15px',
                            backgroundColor: '#f8f9fa',
                            borderRadius: '4px',
                            textAlign: 'center',
                            color: '#6c757d'
                        }}>
                            Click "Calculate Settlements" to see who owes whom!
                        </div>
                    )}
                </div>
            )}

            {/* Clear Data Button */}
            {(users.length > 0 || expenses.length > 0) && (
                <div style={{ textAlign: 'center', marginTop: '20px' }}>
                    <button
                        onClick={clearAllData}
                        style={{
                            padding: '10px 20px',
                            backgroundColor: '#dc3545',
                            color: 'white',
                            border: 'none',
                            borderRadius: '4px',
                            cursor: 'pointer',
                            fontSize: '14px'
                        }}
                    >
                        🗑️ Clear All Data
                    </button>
                </div>
            )}

            {/* Instructions */}
            {users.length === 0 && expenses.length === 0 && (
                <div style={{
                    backgroundColor: 'white',
                    padding: '20px',
                    borderRadius: '8px',
                    textAlign: 'center',
                    color: '#666'
                }}>
                    <h4>🚀 Getting Started</h4>
                    <p>1. Add users who will be sharing expenses</p>
                    <p>2. Add expenses and select participants</p>
                    <p>3. Calculate settlements to see who owes whom!</p>
                </div>
            )}
        </div>
    );
}

export default App;
