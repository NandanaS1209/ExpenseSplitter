package com.expensesplitter.expensesplitter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExpensesplitterApplicationTests {

	@Test
	void contextLoads() {
	}

}
